package com.seedscribe.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Encrypts the provider key with a per-install, non-exportable Android Keystore AES key. */
public final class SecureSettings {
    private static final String ALIAS="com.seedscribe.provider_aes_v1";
    private final SharedPreferences prefs;
    public SecureSettings(Context context) {
        prefs=context.getSharedPreferences("preferences",Context.MODE_PRIVATE);
    }
    public String endpoint() {return prefs.getString("endpoint","https://api.abliteration.ai/v1");}
    public String model() {return prefs.getString("model","abliterated-model");}
    public int fontSize(){return prefs.getInt("font_size",19);}
    public void saveBasic(String endpoint,String model,int fontSize) {
        prefs.edit().putString("endpoint",endpoint).putString("model",model).putInt("font_size",fontSize).apply();
    }
    private SecretKey getAesKey()throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(ks.containsAlias(ALIAS))return ((KeyStore.SecretKeyEntry)ks.getEntry(ALIAS,null)).getSecretKey();
        KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        KeyGenParameterSpec spec=new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build();
        generator.init(spec);return generator.generateKey();
    }
    public void saveApiKey(String key) throws Exception {
        if(key.trim().isEmpty()) {prefs.edit().remove("secret").apply();return;}
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,getAesKey());
        byte[] cipher=c.doFinal(key.trim().getBytes(StandardCharsets.UTF_8));
        byte[] iv=c.getIV();
        // Store IV + ciphertext; an IV is not secret.
        prefs.edit().putString("secret",Base64.encodeToString(iv,Base64.NO_WRAP)+"."
                +Base64.encodeToString(cipher,Base64.NO_WRAP)).apply();
    }
    public boolean hasKey() {return prefs.contains("secret");}
    public String getApiKey() throws Exception {
        String value=prefs.getString("secret",null);
        if(value==null||value.isEmpty())return "";
        String[] parts=value.split("\\.",2);if(parts.length!=2)throw new Exception("Stored key is damaged; set it again");
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE,getAesKey(),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));
        return new String(c.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
    }
}
