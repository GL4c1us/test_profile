package com.seedscribe.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** All source texts and generated stories live under getFilesDir(), never public storage. */
public final class LibraryStore {
    public static final class Seed {
        public String id, name, type;
        public int chars;
        public boolean selected;
        public long importedAt;
        JSONObject toJson() throws Exception {
            return new JSONObject().put("id", id).put("name", name).put("type", type)
                    .put("chars", chars).put("selected", selected).put("importedAt", importedAt);
        }
        static Seed fromJson(JSONObject o) {
            Seed s = new Seed();
            s.id=o.optString("id"); s.name=o.optString("name"); s.type=o.optString("type");
            s.chars=o.optInt("chars"); s.selected=o.optBoolean("selected");
            s.importedAt=o.optLong("importedAt"); return s;
        }
    }
    public static final class Story {
        public String id, title, prompt, model, status, seedNames, seedIds, parentId, branchWord;
        public int targetWords, actualWords;
        public long createdAt;
        JSONObject toJson() throws Exception {
            return new JSONObject().put("id", id).put("title", title).put("prompt", prompt)
                    .put("model", model).put("status", status).put("seedNames", seedNames)
                    .put("seedIds", seedIds).put("parentId", parentId).put("branchWord", branchWord)
                    .put("targetWords", targetWords).put("actualWords", actualWords)
                    .put("createdAt", createdAt);
        }
        static Story fromJson(JSONObject o) {
            Story s = new Story();
            s.id=o.optString("id"); s.title=o.optString("title");
            s.prompt=o.optString("prompt"); s.model=o.optString("model");
            s.status=o.optString("status"); s.seedNames=o.optString("seedNames");
            s.seedIds=o.optString("seedIds"); s.parentId=o.optString("parentId");
            s.branchWord=o.optString("branchWord");
            s.targetWords=o.optInt("targetWords"); s.actualWords=o.optInt("actualWords");
            s.createdAt=o.optLong("createdAt"); return s;
        }
    }

    private final File root, seedsDir, originalsDir, storiesDir, seedIndex, storyIndex;
    public final List<Seed> seeds = new ArrayList<>();
    public final List<Story> stories = new ArrayList<>();

    public LibraryStore(Context context) throws Exception {
        root = new File(context.getFilesDir(), "seed_scribe");
        seedsDir = new File(root, "seeds_text");
        originalsDir = new File(root, "seeds_original");
        storiesDir = new File(root, "stories");
        for (File f : new File[]{root,seedsDir,originalsDir,storiesDir}) {
            if (!f.isDirectory() && !f.mkdirs()) throw new Exception("Cannot create private folder " + f.getName());
        }
        seedIndex=new File(root,"seeds.json"); storyIndex=new File(root,"stories.json");
        JSONArray a=readArray(seedIndex);
        for (int i=0;i<a.length();i++) seeds.add(Seed.fromJson(a.getJSONObject(i)));
        JSONArray b=readArray(storyIndex);
        for (int i=0;i<b.length();i++) {
            Story story=Story.fromJson(b.getJSONObject(i));
            if("Generating".equals(story.status)) story.status="Interrupted";
            stories.add(story);
        }
        saveStories();
    }
    private static JSONArray readArray(File f) throws Exception {
        if (!f.exists()) return new JSONArray();
        return new JSONArray(readUtf8(f));
    }
    public static String readUtf8(File f) throws Exception {
        try (FileInputStream in = new FileInputStream(f); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] b=new byte[16384]; int n;
            while ((n=in.read(b))!=-1) out.write(b,0,n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }
    private static void writeAtomic(File file, String text) throws Exception {
        File temp = new File(file.getParentFile(), file.getName()+".tmp");
        try(FileOutputStream out=new FileOutputStream(temp)) {
            out.write(text.getBytes(StandardCharsets.UTF_8)); out.getFD().sync();
        }
        if (!temp.renameTo(file)) {
            // Some filesystems don't overwrite existing destinations through renameTo.
            if (file.exists() && !file.delete()) throw new Exception("Could not update index");
            if (!temp.renameTo(file)) throw new Exception("Could not finalize " + file.getName());
        }
    }
    private synchronized void saveSeeds() throws Exception {
        JSONArray a=new JSONArray(); for(Seed s:seeds) a.put(s.toJson()); writeAtomic(seedIndex,a.toString());
    }
    private synchronized void saveStories() throws Exception {
        JSONArray a=new JSONArray(); for(Story s:stories) a.put(s.toJson()); writeAtomic(storyIndex,a.toString());
    }
    public synchronized void addSeed(String name, String type, File importedOriginal, String extracted) throws Exception {
        if (extracted.trim().isEmpty()) throw new Exception("No selectable text found in " + name + " (scanned PDFs need OCR)");
        Seed s=new Seed(); s.id=UUID.randomUUID().toString(); s.name=name;
        s.type=type; s.chars=extracted.length(); s.selected=true;
        s.importedAt=System.currentTimeMillis();
        File original=new File(originalsDir,s.id+"."+type);
        File textFile=new File(seedsDir,s.id+".txt");
        try {
            copyFile(importedOriginal,original);
            writeAtomic(textFile,extracted);
            seeds.add(s); saveSeeds();
        } catch (Exception e) {
            seeds.remove(s); original.delete(); textFile.delete(); throw e;
        }
    }
    private static void copyFile(File input,File output) throws Exception {
        try(FileInputStream in=new FileInputStream(input);FileOutputStream out=new FileOutputStream(output)) {
            byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
        }
    }
    public synchronized String textFor(Seed s) throws Exception { return readUtf8(new File(seedsDir,s.id+".txt")); }
    public synchronized void setSelected(Seed s, boolean selected) throws Exception { s.selected=selected;saveSeeds(); }
    public synchronized void setAllSelected(boolean selected) throws Exception {
        for(Seed s:seeds)s.selected=selected;saveSeeds();
    }
    public synchronized void deleteSeed(Seed s) throws Exception {
        seeds.remove(s);saveSeeds(); new File(seedsDir,s.id+".txt").delete();
        new File(originalsDir,s.id+"."+s.type).delete();
    }
    public synchronized Story newStory(String title,String prompt,String model,String seedNames,
            String seedIds,int targetWords,String parentId,String branchWord) throws Exception {
        Story s=new Story(); s.id=UUID.randomUUID().toString();s.title=title;
        s.prompt=prompt;s.model=model;s.seedNames=seedNames;s.seedIds=seedIds;
        s.targetWords=targetWords;s.parentId=parentId;s.branchWord=branchWord;
        s.createdAt=System.currentTimeMillis();s.status="Generating";
        stories.add(0,s);saveStories();writeAtomic(new File(storiesDir,s.id+".txt"),"");return s;
    }
    public synchronized void updateStory(Story s,String text,String status) throws Exception {
        writeAtomic(new File(storiesDir,s.id+".txt"),text);
        s.status=status;s.actualWords=countWords(text);saveStories();
    }
    public synchronized String storyText(Story s) throws Exception {return readUtf8(new File(storiesDir,s.id+".txt"));}
    public synchronized void deleteStory(Story s) throws Exception {
        stories.remove(s); saveStories();new File(storiesDir,s.id+".txt").delete();
    }
    public static int countWords(String text) {
        String s=text.trim();return s.isEmpty()?0:s.split("\\s+").length;
    }
}
