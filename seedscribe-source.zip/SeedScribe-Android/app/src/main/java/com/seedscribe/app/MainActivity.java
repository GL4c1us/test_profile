package com.seedscribe.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native Android UI, no browser, storage, or login required. */
public final class MainActivity extends Activity {
    private static final int PICK_FILE=41, SAVE_STORY=42;
    private static final int BG=Color.rgb(16,15,23), SURFACE=Color.rgb(32,30,43);
    private static final int TXT=Color.rgb(238,235,247), SUB=Color.rgb(175,169,190);
    private static final int ACC=Color.rgb(196,173,255), LINE=Color.rgb(65,59,80);
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Handler ui=new Handler(Looper.getMainLooper());
    private LibraryStore library;
    private SecureSettings settings;
    private LinearLayout page, tabs;
    private String screen="create", draftTitle="", draftPrompt="";
    private int draftWords=1500;
    private volatile boolean busy=false, stopRequested=false;
    private String generationStatus="";
    private LibraryStore.Story exportingStory;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        try {library=new LibraryStore(this);settings=new SecureSettings(this);}
        catch(Exception e){new AlertDialog.Builder(this).setTitle("Cannot open library")
                .setMessage(e.getMessage()).setPositiveButton("Close",(d,w)->finish()).show();return;}
        setupShell();show("create");
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable shape(int color,int border,int radius) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));
        if(border!=0)d.setStroke(dp(1),border);return d;
    }
    private void setupShell(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        setContentView(root);
        // Android 15+ enforces edge-to-edge drawing for apps targeting API 35+.
        if(Build.VERSION.SDK_INT>=35){
            root.setOnApplyWindowInsetsListener((view,insets)->{
                Insets bars=insets.getInsets(WindowInsets.Type.systemBars());
                root.setPadding(bars.left,bars.top,bars.right,bars.bottom);
                return insets;
            });
        }
        LinearLayout masthead=new LinearLayout(this);masthead.setOrientation(LinearLayout.VERTICAL);
        masthead.setPadding(dp(22),dp(20),dp(22),dp(14));
        TextView logo=text("✦  SEEDSCRIBE",21,ACC,true);logo.setLetterSpacing(.12f);masthead.addView(logo);
        TextView tagline=text("A private library for unwritten worlds",12,SUB,false);tagline.setPadding(0,dp(6),0,0);
        masthead.addView(tagline);root.addView(masthead);
        View rule=new View(this);rule.setBackgroundColor(LINE);root.addView(rule,new LinearLayout.LayoutParams(-1,dp(1)));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(18),dp(22),dp(18),dp(28));
        scroll.addView(page);
        tabs=new LinearLayout(this);tabs.setPadding(dp(8),dp(7),dp(8),dp(9));tabs.setBackgroundColor(SURFACE);
        root.addView(tabs);
    }
    private TextView text(String str,int sp,int color,boolean bold){
        TextView tv=new TextView(this);tv.setText(str);tv.setTextSize(sp);tv.setTextColor(color);
        if(bold)tv.setTypeface(Typeface.DEFAULT,Typeface.BOLD);tv.setIncludeFontPadding(false);return tv;
    }
    private void space(LinearLayout into,int height){View v=new View(this);into.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private void add(LinearLayout into, View v,int bottom){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(bottom);into.addView(v,p);
    }
    private TextView heading(String title,String subtitle){
        TextView tv=text(title,26,TXT,true);add(page,tv,8);
        if(subtitle!=null&&!subtitle.isEmpty()){
            TextView small=text(subtitle,14,SUB,false);small.setLineSpacing(dp(3),1f);add(page,small,18);
        }else space(page,12);
        return tv;
    }
    private TextView label(String name){TextView tv=text(name.toUpperCase(Locale.ROOT),12,ACC,true);tv.setLetterSpacing(.12f);add(page,tv,9);return tv;}
    private EditText input(String content,String hint,int lines){
        EditText e=new EditText(this);e.setTextColor(TXT);e.setHintTextColor(SUB);e.setTextSize(16);
        e.setPadding(dp(14),dp(12),dp(14),dp(12));e.setBackground(shape(SURFACE,LINE,12));
        e.setHint(hint);e.setText(content);e.setSingleLine(lines==1);
        if(lines>1){e.setMinLines(lines);e.setGravity(Gravity.TOP);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);}
        add(page,e,17);return e;
    }
    private Button button(String title,boolean primary,Runnable action){
        Button b=new Button(this);b.setText(title);b.setTextAllCaps(false);b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setMinHeight(dp(48));
        b.setTextColor(primary?BG:ACC);
        b.setBackground(shape(primary?ACC:SURFACE,primary?0:LINE,12));
        b.setOnClickListener(v->action.run());return b;
    }
    private void buttonRow(LinearLayout owner,String first,Runnable a,String second,Runnable b){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        Button left=button(first,true,a),right=button(second,false,b);
        LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(0,dp(51),1);x.rightMargin=dp(8);row.addView(left,x);
        row.addView(right,new LinearLayout.LayoutParams(0,dp(51),1));add(owner,row,14);
    }
    private LinearLayout card(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16),dp(16),dp(16),dp(16));box.setBackground(shape(SURFACE,LINE,14));
        add(page,box,12);return box;
    }
    private void note(LinearLayout parent,String msg){
        TextView small=text(msg,13,SUB,false);small.setLineSpacing(dp(3),1.1f);add(parent,small,10);
    }
    private void nav(){
        tabs.removeAllViews();String[][] choices={{"seeds","Seeds"},{"create","Create"},{"stories","Stories"},{"settings","Settings"}};
        for(String[] choice:choices){
            boolean active=choice[0].equals(screen)||("reader".equals(screen)&&"stories".equals(choice[0]));
            TextView t=text(choice[1],13,active?ACC:SUB,active);t.setGravity(Gravity.CENTER);t.setPadding(0,dp(12),0,dp(12));
            t.setBackground(shape(active?Color.rgb(52,44,71):SURFACE,0,10));
            t.setOnClickListener(v->show(choice[0]));tabs.addView(t,new LinearLayout.LayoutParams(0,-2,1));
        }
    }
    private void show(String to){
        screen=to;page.removeAllViews();nav();
        switch(to){case "seeds":showSeeds();break;case "create":showCreate();break;
            case "stories":showStories();break;case "settings":showSettings();break;default:showCreate();}
    }
    private void alert(String title,String detail){
        if(isFinishing())return;
        new AlertDialog.Builder(this).setTitle(title).setMessage(detail)
                .setPositiveButton("OK",null).show();
    }
    private void fail(Exception e){runOnUiThread(()->alert("Something went wrong",e.getMessage()==null?e.toString():e.getMessage()));}
    private void watch(EditText field,java.util.function.Consumer<String> onChange){
        field.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){onChange.accept(s.toString());}
            @Override public void afterTextChanged(Editable s){}
        });
    }

    private void showSeeds(){
        long chosen=library.seeds.stream().filter(s->s.selected).count();
        heading("Reference library",library.seeds.size()+" documents · "+chosen+" selected for generation");
        add(page,button("＋ Import ZIP / TXT / PDF",true,this::pickFile),18);
        note(page,"Files are copied into this app's private storage. PDF text is extracted for prompting. Scanned image-only PDFs need OCR (not included).");
        buttonRow(page,"Select all",()->setAll(true),"Select none",()->setAll(false));
        if(library.seeds.isEmpty())note(page,"No writing samples yet. Import a ZIP archive containing .txt and .pdf files, or add individual files.");
        for(LibraryStore.Seed seed:new ArrayList<>(library.seeds)){
            LinearLayout c=card();
            CheckBox check=new CheckBox(this);check.setText(seed.name);check.setTextColor(TXT);
            check.setTextSize(16);check.setChecked(seed.selected);check.setButtonTintList(android.content.res.ColorStateList.valueOf(ACC));
            check.setOnCheckedChangeListener((v,value)->{
                try{library.setSelected(seed,value);}catch(Exception e){alert("Cannot save",e.getMessage());}
            });add(c,check,7);
            note(c,seed.type.toUpperCase(Locale.ROOT)+" · "+seed.chars+" characters");
            LinearLayout row=new LinearLayout(this);
            Button preview=button("Preview",false,()->previewSeed(seed));
            Button delete=button("Remove",false,()->new AlertDialog.Builder(this)
                    .setTitle("Remove seed?").setMessage("Delete “"+seed.name+"” from this app?")
                    .setNegativeButton("Cancel",null).setPositiveButton("Remove",(d,w)->{
                        try{library.deleteSeed(seed);show("seeds");}catch(Exception e){alert("Delete failed",e.getMessage());}
                    }).show());
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),1);p.rightMargin=dp(8);
            row.addView(preview,p);row.addView(delete,new LinearLayout.LayoutParams(0,dp(44),1));c.addView(row);
        }
    }
    private void setAll(boolean selected){try{library.setAllSelected(selected);show("seeds");}catch(Exception e){alert("Save failed",e.getMessage());}}
    private void pickFile(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/zip","application/x-zip-compressed","text/plain","application/pdf","application/octet-stream"});
        startActivityForResult(i,PICK_FILE);
    }
    private void previewSeed(LibraryStore.Seed seed){
        worker.execute(()->{
            try{
                String whole=library.textFor(seed);
                String snippet=whole.substring(0,Math.min(12000,whole.length()));
                runOnUiThread(()->new AlertDialog.Builder(this).setTitle(seed.name)
                        .setMessage(snippet+(whole.length()>12000?"\n\n… preview truncated":""))
                        .setPositiveButton("Done",null).show());
            }catch(Exception e){fail(e);}
        });
    }
    private void showCreate(){
        heading("Write a new story","Select reference documents, write your direction, and choose how long the story should be.");
        long count=library.seeds.stream().filter(s->s.selected).count();
        LinearLayout info=card();add(info,text(count+" active writing seeds",16,ACC,true),6);
        note(info,"All selected seed text is included in the request. Large libraries may exceed the model's context limit or raise API costs.");
        add(info,button("Manage seeds",false,()->show("seeds")),0);space(page,6);
        label("Story title");EditText title=input(draftTitle,"A title for your library",1);
        watch(title,s->draftTitle=s);
        label("Writing prompt");EditText prompt=input(draftPrompt,"Describe the world, characters, tone, plot, boundaries, and what should happen…",7);
        watch(prompt,s->draftPrompt=s);
        label("Approximate word count");EditText words=input(String.valueOf(draftWords),"1500",1);
        words.setInputType(InputType.TYPE_CLASS_NUMBER);
        watch(words,s->{try{draftWords=Integer.parseInt(s);}catch(Exception ignored){draftWords=0;}});
        note(page,"For longer stories, the app makes multiple sequential API requests and saves each installment. Word counts are targets, not guarantees.");
        if(!settings.hasKey()){
            LinearLayout warning=card();add(warning,text("API key not configured",16,ACC,true),10);
            add(warning,button("Open settings",false,()->show("settings")),0);
        }
        if(busy){
            LinearLayout progress=card();add(progress,text("Generating…",18,TXT,true),8);
            note(progress,generationStatus);
            add(progress,button("Stop after current API response",false,()->{stopRequested=true;generationStatus="Stopping after the current response…";}),0);
        }else add(page,button("✦ Generate story",true,()->startNewStory()),16);
    }
    private void startNewStory(){
        if(busy){alert("Please wait","Only one story can generate at a time.");return;}
        if(!settings.hasKey()){show("settings");alert("API key needed","Enter your Abliteration AI key before generating.");return;}
        if(draftPrompt.trim().isEmpty()){alert("Prompt needed","Enter story instructions before generating.");return;}
        if(draftWords<100||draftWords>20000){alert("Word count","Enter a target between 100 and 20,000 words.");return;}
        ArrayList<LibraryStore.Seed> refs=new ArrayList<>();for(LibraryStore.Seed s:library.seeds)if(s.selected)refs.add(s);
        startGeneration(draftTitle.trim().isEmpty()?"Untitled story":draftTitle.trim(),
                draftPrompt.trim(),draftWords,refs,null,"","");
    }
    private String seedNames(List<LibraryStore.Seed> refs){
        StringBuilder s=new StringBuilder();for(LibraryStore.Seed ref:refs){if(s.length()>0)s.append(", ");s.append(ref.name);}return s.toString();
    }
    private String seedIds(List<LibraryStore.Seed> refs){
        StringBuilder s=new StringBuilder();for(LibraryStore.Seed ref:refs){if(s.length()>0)s.append(",");s.append(ref.id);}return s.toString();
    }
    private void startGeneration(String title,String prompt,int targetWords,
            ArrayList<LibraryStore.Seed> refs,LibraryStore.Story parent,String branchWord,String existingPrefix){
        if(busy)return;
        final LibraryStore.Story entry;
        try {
            entry=library.newStory(title,prompt,settings.model(),seedNames(refs),seedIds(refs),targetWords,
                    parent==null?"":parent.id,branchWord);
            if(!existingPrefix.isEmpty())library.updateStory(entry,existingPrefix,"Generating");
        }catch(Exception e){alert("Cannot save story",e.getMessage());return;}
        busy=true;stopRequested=false;generationStatus="Contacting Abliteration AI…";
        show("create");
        worker.execute(()->{
            try {
                String key=settings.getApiKey();
                String output=StoryGenerator.generate(library,refs,settings.endpoint(),key,entry.model,
                        prompt,targetWords,existingPrefix,new StoryGenerator.Progress(){
                    @Override public boolean cancelled(){return stopRequested;}
                    @Override public void checkpoint(String text,int totalWords,int requests) throws Exception {
                        library.updateStory(entry,text,"Generating");
                        generationStatus=totalWords+" / ~"+targetWords+" words · "+requests+" API requests";
                        runOnUiThread(()->{if("create".equals(screen))show("create");});
                    }
                });
                library.updateStory(entry,output,"Complete");
                generationStatus="Finished";
                runOnUiThread(()->{busy=false;showReader(entry);});
            }catch(Exception e){
                try{String previous=library.storyText(entry);library.updateStory(entry,previous,"Interrupted");}catch(Exception ignored){}
                runOnUiThread(()->{
                    busy=false;show("stories");
                    String msg=e instanceof InterruptedException?"The partial draft was saved. You can read it in Stories.":
                            "The draft was saved through its latest checkpoint.\n\n"+e.getMessage();
                    alert(e instanceof InterruptedException?"Generation stopped":"Generation interrupted",msg);
                });
            }
        });
    }
    private void showStories(){
        heading("Your stories",library.stories.size()+" saved drafts and completed works");
        if(library.stories.isEmpty())note(page,"Nothing written yet. Create a story, then it will appear here automatically.");
        for(LibraryStore.Story s:new ArrayList<>(library.stories)){
            LinearLayout c=card();
            add(c,text(s.title,18,TXT,true),8);
            note(c,s.status+" · "+s.actualWords+" words · "+DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT).format(new Date(s.createdAt)));
            if(!s.parentId.isEmpty())note(c,"↳ Branched at “"+s.branchWord+"” from an earlier story");
            Button open=button("Read / rewrite",false,()->showReader(s));add(c,open,8);
            Button del=button("Delete",false,()->new AlertDialog.Builder(this).setTitle("Delete this story?")
                    .setMessage("This permanently deletes “"+s.title+"” from the local app library.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{
                        try{library.deleteStory(s);show("stories");}catch(Exception e){alert("Delete failed",e.getMessage());}
                    }).show());add(c,del,0);
        }
    }
    private void showReader(LibraryStore.Story s){
        final String full;
        try{full=library.storyText(s);}catch(Exception e){alert("Cannot load story",e.getMessage());return;}
        screen="reader";page.removeAllViews();nav();
        add(page,button("‹  Back to stories",false,()->show("stories")),16);
        heading(s.title,s.actualWords+" words · "+s.status+(s.parentId.isEmpty()?"":" · branched revision"));
        LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);
        Button export=button("Export TXT",false,()->exportStory(s));
        Button select=button("How to rewrite",false,()->alert("Rewrite from a word",
                "Press and HOLD any word in the story below for 2 seconds. The app will keep the text through that word and regenerate everything that follows using a new prompt. Your original story stays saved."));
        LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,dp(48),1);a.rightMargin=dp(8);
        tools.addView(export,a);tools.addView(select,new LinearLayout.LayoutParams(0,dp(48),1));add(page,tools,14);
        if(full.trim().isEmpty()){note(page,"This draft doesn't contain any generated text yet.");return;}
        TextView tip=text("HOLD ANY WORD FOR 2 SECONDS TO REWRITE FROM THAT POINT",11,ACC,true);
        tip.setLetterSpacing(.08f);add(page,tip,16);
        TextView novel=text("",settings.fontSize(),TXT,false);
        novel.setLineSpacing(dp(6),1.15f);
        novel.setPadding(dp(17),dp(22),dp(17),dp(24));
        novel.setBackground(shape(Color.rgb(25,24,34),LINE,14));
        novel.setText(formatStory(full));add(page,novel,30);
        attachTwoSecondWordHold(novel,full,(word,cut)->showRewriteDialog(s,full,word,cut));
    }
    private SpannableString formatStory(String source){
        SpannableString styled=new SpannableString(source);
        int lineStart=0;
        while(lineStart<source.length()){
            int next=source.indexOf('\n',lineStart);if(next<0)next=source.length();
            String line=source.substring(lineStart,next).trim();
            if(line.startsWith("# ")||line.startsWith("## ")||line.matches("(?i)chapter\\s+[\\divxlc]+.*")){
                styled.setSpan(new StyleSpan(Typeface.BOLD),lineStart,next,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                styled.setSpan(new RelativeSizeSpan(1.24f),lineStart,next,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                styled.setSpan(new ForegroundColorSpan(ACC),lineStart,next,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }else if(line.equals("***")||line.equals("---")){
                styled.setSpan(new ForegroundColorSpan(ACC),lineStart,next,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            lineStart=next+1;
        }
        return styled;
    }
    private interface WordHeld{void selected(String word,int endOffset);}
    /** Two FULL seconds are required; finger movement cancels the selection. */
    private void attachTwoSecondWordHold(TextView view,String raw,WordHeld onWord){
        final float[] origin={0,0};final Runnable[] pending={null};
        final int slop=ViewConfiguration.get(this).getScaledTouchSlop();
        view.setOnTouchListener((v,event)->{
            switch(event.getActionMasked()){
                case MotionEvent.ACTION_DOWN: {
                    origin[0]=event.getX();origin[1]=event.getY();
                    final float x=origin[0],y=origin[1];
                    Runnable r=()->{
                        pending[0]=null;
                        StoryAnchor anchor=StoryAnchor.at(raw,view.getOffsetForPosition(x,y));
                        if(anchor!=null){view.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                            onWord.selected(anchor.word,anchor.endOffset);}
                    };
                    pending[0]=r;ui.postDelayed(r,2000);
                    return true;
                }
                case MotionEvent.ACTION_MOVE:
                    if(Math.abs(event.getX()-origin[0])>slop || Math.abs(event.getY()-origin[1])>slop){
                        if(pending[0]!=null)ui.removeCallbacks(pending[0]);pending[0]=null;
                    }return true;
                case MotionEvent.ACTION_CANCEL:case MotionEvent.ACTION_UP:
                    if(pending[0]!=null)ui.removeCallbacks(pending[0]);pending[0]=null;
                    if(event.getActionMasked()==MotionEvent.ACTION_UP)view.performClick();
                    return true;
                default:return true;
            }
        });
    }
    private void showRewriteDialog(LibraryStore.Story parent,String full,String word,int cut){
        if(busy){alert("Already generating","Wait until the active generation finishes.");return;}
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20),dp(10),dp(20),0);
        TextView explanation=text("Keep everything through “"+word+"”. Replace ALL text after it, using a new writing prompt. The original version will remain in Stories.",15,TXT,false);
        add(form,explanation,16);
        EditText custom=new EditText(this);custom.setHint("How should the story change from here?");
        custom.setTextColor(TXT);custom.setHintTextColor(SUB);custom.setMinLines(5);custom.setGravity(Gravity.TOP);
        custom.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        custom.setText(parent.prompt);add(form,custom,12);
        add(form,text("Target total words, INCLUDING the preserved prefix:",13,SUB,false),4);
        EditText target=new EditText(this);target.setInputType(InputType.TYPE_CLASS_NUMBER);
        target.setText(String.valueOf(Math.max(parent.targetWords,LibraryStore.countWords(full.substring(0,cut))+300)));
        target.setTextColor(TXT);add(form,target,8);
        new AlertDialog.Builder(this).setTitle("Rewrite after “"+word+"”").setView(form)
                .setNegativeButton("Cancel",null).setPositiveButton("Create revision",(d,w)->{
                    String prompt=custom.getText().toString().trim();int words;
                    try{words=Integer.parseInt(target.getText().toString().trim());}
                    catch(Exception e){alert("Invalid word count","Enter a number.");return;}
                    int prefixWords=LibraryStore.countWords(full.substring(0,cut));
                    if(prompt.isEmpty()||words<=prefixWords||words>20000){
                        alert("Invalid revision","Enter a nonempty prompt and a target greater than the preserved "
                                +prefixWords+" words (max 20,000).");return;
                    }
                    if(!settings.hasKey()){show("settings");alert("API key needed","Configure the API key first.");return;}
                    ArrayList<LibraryStore.Seed> sourceRefs=new ArrayList<>();
                    if(!parent.seedIds.isEmpty()){
                        for(String id:parent.seedIds.split(","))for(LibraryStore.Seed s:library.seeds)if(s.id.equals(id))sourceRefs.add(s);
                        if(!parent.seedNames.isEmpty()&&sourceRefs.isEmpty()){
                            alert("Original seeds missing","All of this story's seed documents were deleted. Reimport them first.");return;
                        }
                    }
                    String title=parent.title+" · rewrite @ "+word;
                    startGeneration(title,prompt,words,sourceRefs,parent,word,full.substring(0,cut));
                }).show();
    }
    private void exportStory(LibraryStore.Story s){
        exportingStory=s;
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/plain");
        String basename=s.title.replaceAll("[^a-zA-Z0-9._ -]","_");
        i.putExtra(Intent.EXTRA_TITLE,basename+".txt");startActivityForResult(i,SAVE_STORY);
    }
    private void showSettings(){
        heading("Connection & reader","Your key is encrypted on this device with Android Keystore. It is never bundled into the app.");
        label("Abliteration API key");
        EditText key=input("","Paste API key (leave blank to keep existing)",1);
        key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        note(page,settings.hasKey()?"An API key is saved. Enter a new value only to replace it.":"No API key saved yet.");
        label("API base URL");EditText endpoint=input(settings.endpoint(),"https://api.abliteration.ai/v1",1);
        label("Model identifier");EditText model=input(settings.model(),"abliterated-model",1);
        label("Reader font size (sp)");EditText font=input(String.valueOf(settings.fontSize()),"19",1);
        font.setInputType(InputType.TYPE_CLASS_NUMBER);
        add(page,button("Save settings",true,()->{
            try{
                int size=Integer.parseInt(font.getText().toString().trim());
                if(size<12||size>34)throw new Exception("Font size must be 12–34 sp");
                String base=endpoint.getText().toString().trim();
                java.net.URI parsed=new java.net.URI(base);
                if(!"https".equalsIgnoreCase(parsed.getScheme())||parsed.getHost()==null)
                    throw new Exception("Use a valid HTTPS API URL");
                String id=model.getText().toString().trim();
                if(id.isEmpty())throw new Exception("Model identifier cannot be empty");
                settings.saveBasic(base,id,size);
                if(!key.getText().toString().trim().isEmpty())settings.saveApiKey(key.getText().toString());
                show("settings");alert("Saved","Your configuration has been saved locally.");
            }catch(Exception e){alert("Invalid settings",e.getMessage());}
        }),12);
        if(settings.hasKey())add(page,button("Remove saved API key",false,()->new AlertDialog.Builder(this)
                .setTitle("Remove key?").setPositiveButton("Remove",(d,w)->{
                    try{settings.saveApiKey("");show("settings");}catch(Exception e){alert("Remove failed",e.getMessage());}
                }).setNegativeButton("Cancel",null).show()),10);
        LinearLayout details=card();add(details,text("PRIVACY",13,ACC,true),9);
        note(details,"Imported documents and generated drafts stay in the app's private internal folder until deleted. "
                +"For generation, selected texts, your prompt, and recent story context are transmitted to the configured API provider over HTTPS. "
                +"Android backups are disabled for this app.");
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(request==PICK_FILE){
            generationStatus="Importing documents…";
            worker.execute(()->{
                try{SeedImporter.Result outcome=SeedImporter.importUri(this,library,uri);
                    runOnUiThread(()->{show("seeds");alert("Import results",outcome.message());});
                }catch(Exception e){fail(e);}
            });
        }else if(request==SAVE_STORY&&exportingStory!=null){
            LibraryStore.Story toWrite=exportingStory;exportingStory=null;
            worker.execute(()->{
                try(OutputStream out=getContentResolver().openOutputStream(uri)){
                    if(out==null)throw new Exception("Cannot write to this destination");
                    out.write(library.storyText(toWrite).getBytes(StandardCharsets.UTF_8));
                    runOnUiThread(()->alert("Export complete","Story saved to your chosen location."));
                }catch(Exception e){fail(e);}
            });
        }
    }
    @Override public void onBackPressed(){
        if("reader".equals(screen))show("stories");
        else if(!"create".equals(screen))show("create");
        else super.onBackPressed();
    }
    @Override protected void onDestroy(){super.onDestroy();worker.shutdown();}
}
