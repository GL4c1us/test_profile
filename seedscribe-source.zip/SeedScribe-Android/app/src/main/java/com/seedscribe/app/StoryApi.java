package com.seedscribe.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class StoryApi {
    private static String read(InputStream in)throws Exception {
        if(in==null)return "";
        try(InputStream source=in;ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] b=new byte[8192];int n;long total=0;
            while((n=source.read(b))!=-1) {
                total+=n;if(total>5_000_000)throw new Exception("Provider response too large");
                out.write(b,0,n);
            }
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }
    public static String complete(String baseUrl,String key,String model,String system,String user,int outputTokens)throws Exception {
        URI base=new URI(baseUrl.trim());
        if(!"https".equalsIgnoreCase(base.getScheme()) || base.getHost()==null
                || base.getRawUserInfo()!=null || base.getQuery()!=null || base.getFragment()!=null)
            throw new Exception("Endpoint must be a valid HTTPS base URL");
        String path=base.getPath()==null?"":base.getPath().replaceAll("/+$", "");
        if(path.endsWith("/chat/completions")) path=path.substring(0,path.length()-"/chat/completions".length());
        if(path.isEmpty()) path="/v1";
        URL url=new URI("https",null,base.getHost(),base.getPort(),path+"/chat/completions",null,null).toURL();
        JSONObject body=new JSONObject();
        body.put("model",model);
        body.put("stream",false);
        body.put("temperature",0.8);
        body.put("max_tokens",outputTokens);
        JSONArray messages=new JSONArray();
        messages.put(new JSONObject().put("role","system").put("content",system));
        messages.put(new JSONObject().put("role","user").put("content",user));
        body.put("messages",messages);
        byte[] json=body.toString().getBytes(StandardCharsets.UTF_8);
        if(json.length>7_000_000)throw new Exception("Selected seeds exceed the 7 MB request safety limit. Deselect some files.");
        HttpURLConnection c=(HttpURLConnection)url.openConnection();
        c.setRequestMethod("POST");c.setConnectTimeout(30_000);c.setReadTimeout(180_000);
        c.setDoOutput(true);c.setInstanceFollowRedirects(false);
        c.setRequestProperty("Authorization","Bearer "+key);
        c.setRequestProperty("Content-Type","application/json; charset=utf-8");
        c.setRequestProperty("Accept","application/json");
        c.setFixedLengthStreamingMode(json.length);
        try {
            try(OutputStream out=c.getOutputStream()){out.write(json);}
            int code=c.getResponseCode();
            String response=read(code>=200&&code<300?c.getInputStream():c.getErrorStream());
            if(code<200||code>=300) {
                String detail=response;
                try {
                    JSONObject err=new JSONObject(response);
                    if(err.has("error")) {
                        Object obj=err.get("error");
                        detail=obj instanceof JSONObject?((JSONObject)obj).optString("message",obj.toString()):obj.toString();
                    } else detail=err.optString("message",response);
                } catch(Exception ignored) {}
                throw new Exception("API HTTP "+code+": "+detail.substring(0,Math.min(450,detail.length())));
            }
            JSONObject result=new JSONObject(response);
            JSONArray choices=result.optJSONArray("choices");
            if(choices==null||choices.length()==0)throw new Exception("Provider returned no story text");
            JSONObject message=choices.getJSONObject(0).optJSONObject("message");
            if(message==null)throw new Exception("Provider returned no message");
            String text=message.optString("content","");
            if(text.trim().isEmpty())throw new Exception("Provider returned an empty story");
            return text.trim();
        } finally {c.disconnect();}
    }
}
