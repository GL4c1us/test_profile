package com.seedscribe.app;

/** Resolves a touched character offset to a precise word and immutable cut position. */
public final class StoryAnchor {
    public final String word;
    public final int startOffset, endOffset;
    private StoryAnchor(String word,int start,int end){
        this.word=word;this.startOffset=start;this.endOffset=end;
    }
    private static boolean partOfWord(char c){
        return Character.isLetterOrDigit(c)||c=='\''||c=='’'||c=='-';
    }
    public static StoryAnchor at(String text,int clickedOffset){
        if(text==null||text.isEmpty())return null;
        int start=Math.max(0,Math.min(clickedOffset,text.length()-1));
        if(!partOfWord(text.charAt(start))&&start>0&&partOfWord(text.charAt(start-1)))start--;
        if(!partOfWord(text.charAt(start)))return null;
        while(start>0&&partOfWord(text.charAt(start-1)))start--;
        int end=start;
        while(end<text.length()&&partOfWord(text.charAt(end)))end++;
        return new StoryAnchor(text.substring(start,end),start,end);
    }
}
