package com.seedscribe.app;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class SeedImporter {
    private static final long MAX_FILE_BYTES=25L*1024*1024;
    private static final long MAX_ZIP_TOTAL=120L*1024*1024;
    private static final int MAX_ENTRIES=200;

    public static final class Result {
        public int imported;
        public final List<String> skipped=new ArrayList<>();
        public String message() {
            StringBuilder b=new StringBuilder("Imported ").append(imported).append(" writing(s).");
            if (!skipped.isEmpty()) {
                b.append("\n\nSkipped ").append(skipped.size()).append(":\n");
                for(int i=0;i<Math.min(skipped.size(),10);i++)b.append("• ").append(skipped.get(i)).append('\n');
            }
            return b.toString();
        }
    }

    public static Result importUri(Context ctx, LibraryStore store, Uri uri) throws Exception {
        PDFBoxResourceLoader.init(ctx.getApplicationContext());
        String filename=displayName(ctx,uri);
        String ext=extension(filename);
        File uploaded=File.createTempFile("seed-source-",".tmp",ctx.getCacheDir());
        try {
            ContentResolver resolver=ctx.getContentResolver();
            try(InputStream in=resolver.openInputStream(uri)) {
                if(in==null)throw new Exception("Cannot open selected document");
                copyBounded(in,uploaded,MAX_ZIP_TOTAL);
            }
            Result result=new Result();
            if(ext.equals("zip")) {
                long total=0;int count=0;
                try(ZipInputStream zip=new ZipInputStream(new FileInputStream(uploaded))) {
                    ZipEntry entry;
                    while((entry=zip.getNextEntry())!=null) {
                        if(entry.isDirectory()) {zip.closeEntry();continue;}
                        if(++count>MAX_ENTRIES)throw new Exception("Archive contains more than "+MAX_ENTRIES+" files");
                        String entryName=new File(entry.getName().replace('\\','/')).getName();
                        String innerExt=extension(entryName);
                        if(!innerExt.equals("txt")&&!innerExt.equals("pdf")) {
                            result.skipped.add(entryName+" (not TXT or PDF)");zip.closeEntry();continue;
                        }
                        File tmp=File.createTempFile("seed-entry-",".tmp",ctx.getCacheDir());
                        try {
                            long bytes=copyBounded(zip,tmp,MAX_FILE_BYTES);
                            total+=bytes;
                            if(total>MAX_ZIP_TOTAL)throw new Exception("ZIP is too large when extracted (120 MB limit)");
                            try { importOne(store,entryName,innerExt,tmp);result.imported++; }
                            catch(Exception e){result.skipped.add(entryName+": "+e.getMessage());}
                        } finally {tmp.delete();zip.closeEntry();}
                    }
                }
            } else if(ext.equals("txt")||ext.equals("pdf")) {
                importOne(store,filename,ext,uploaded);result.imported++;
            } else throw new Exception("Choose a .zip, .txt, or .pdf file");
            return result;
        } finally { uploaded.delete(); }
    }
    private static void importOne(LibraryStore store,String name,String ext,File file) throws Exception {
        String text;
        if(ext.equals("pdf")) {
            try(PDDocument document=PDDocument.load(file)) {
                if(document.isEncrypted())throw new Exception("Encrypted PDF is not supported");
                PDFTextStripper stripper=new PDFTextStripper();
                stripper.setSortByPosition(true);
                text=stripper.getText(document);
            }
        } else {
            byte[] bytes=readBytes(file);
            if(bytes.length>=3 && (bytes[0]&255)==0xEF&&(bytes[1]&255)==0xBB&&(bytes[2]&255)==0xBF) {
                text=new String(bytes,3,bytes.length-3,StandardCharsets.UTF_8);
            } else if(bytes.length>=2 && (bytes[0]&255)==0xFF&&(bytes[1]&255)==0xFE) {
                text=new String(bytes,2,bytes.length-2,StandardCharsets.UTF_16LE);
            } else if(bytes.length>=2 && (bytes[0]&255)==0xFE&&(bytes[1]&255)==0xFF) {
                text=new String(bytes,2,bytes.length-2,StandardCharsets.UTF_16BE);
            } else text=new String(bytes,StandardCharsets.UTF_8);
        }
        store.addSeed(name,ext,file,text);
    }
    private static byte[] readBytes(File f)throws Exception {
        try(FileInputStream in=new FileInputStream(f); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] buf=new byte[16384];int n;
            while((n=in.read(buf))!=-1)out.write(buf,0,n);
            return out.toByteArray();
        }
    }
    private static long copyBounded(InputStream in, File destination,long maxBytes) throws Exception {
        long total=0;byte[] b=new byte[16384];int n;
        try(FileOutputStream out=new FileOutputStream(destination)) {
            while((n=in.read(b))!=-1) {
                total+=n;if(total>maxBytes)throw new Exception("File exceeds "+(maxBytes/1024/1024)+" MB limit");
                out.write(b,0,n);
            }
        }
        return total;
    }
    private static String extension(String name) {
        int i=name.lastIndexOf('.');return i<0?"":name.substring(i+1).toLowerCase(Locale.ROOT);
    }
    private static String displayName(Context ctx, Uri uri) {
        String name=null;
        try(Cursor c=ctx.getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) {
            if(c!=null&&c.moveToFirst())name=c.getString(0);
        } catch(Exception ignored) { }
        if(name==null||name.trim().isEmpty())name=uri.getLastPathSegment();
        return name==null?"import.txt":new File(name.replace('\\','/')).getName();
    }
}
