# SeedScribe — native Android story generator

An independent Android app designed for a Pixel 11 Pro. Written in Java with native Android views. Nothing needs a hosted database or an account besides your own Abliteration AI API key.

## What it does

1. **Seeds** — import `.zip`, `.txt`, and `.pdf` files from Android's system file picker. ZIPs can contain nested folders; only their TXT/PDF contents are imported. Original documents **and** extracted plain text are stored under the app-private `getFilesDir()/seed_scribe/` folder, keyed by unique IDs. Select all, select none, select particular seeds, preview, or remove individual files.
2. **Create** — type a story prompt, optional title, and approximate target word count (100–20,000). All selected seed texts are included with the prompt in the chat-completions request. Generation is chunked for longer stories, with progress checkpoints saved to the private library.
3. **Stories** — read and export `.txt` stories, revisit partial or complete drafts, delete copies.
4. **Branch-and-rewrite** — while reading, **hold down a word for 2 full seconds** (without moving your finger). Enter new instructions and a target **total** word count. The selected word stays; **everything from the character immediately after it is replaced**. Your original story remains unchanged, while a new revision with a parent reference appears in Stories.
5. **Settings** — HTTPS API base URL, model ID, reader font size, and API key. AES-256-GCM encryption with a non-exportable Android Keystore key protects the locally saved API key.

## Provider configuration

- Default base URL: `https://api.abliteration.ai/v1`
- Default model: `abliterated-model`
- Request: `POST /v1/chat/completions`, `Authorization: Bearer <your API key>`
- The base URL and model are editable for the provider's model changes.
- No API key is embedded in source, manifests or build files.

Official API reference: https://abliteration.ai/docs/openai-compatibility

## Build an APK

### Option A — Android Studio (recommended)

1. Extract this entire ZIP to a folder on your computer.
2. Open that folder as a project in a recent **Android Studio** and allow it to download Gradle and platform dependencies.
3. Ensure that Android SDK Platform **35** is installed.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)** (or run the `:app:assembleDebug` Gradle task).
5. The debug APK is `app/build/outputs/apk/debug/app-debug.apk`; transfer it to the Pixel 11 Pro and open it to install, allowing installation from that trusted source if Android asks.

**Note:** The source archive does not include Gradle's binary wrapper JAR. Android Studio can use its installed Gradle distribution, or you can run `gradle :app:assembleDebug` from a terminal with Gradle **8.11.1** and JDK **17**. If you prefer wrapper scripts, run `gradle wrapper --gradle-version 8.11.1` once.

### Option B — GitHub Actions (no local Android SDK needed)

1. Upload the project contents to a **private** GitHub repository.
2. Run **Actions > Build Android debug APK > Run workflow** (or push to `main`).
3. Download the **SeedScribe-debug-APK** artifact from the successful run, unzip that artifact and install `app-debug.apk` on your phone.

The workflow is stored in `.github/workflows/build-apk.yml`. The APK is a **debug** build, signed with the normal temporary debug key. For permanent redistribution use Android Studio's **Generate Signed Bundle / APK** with your own release signing key.

## Privacy, cost, and practical limits

- Seeds and generated stories are **private to the app on the device**, but **any selected seed text, your writing prompt, and recent story context are transmitted to your chosen API provider** when generating. Do not include data you do not want to transmit.
- Android automatic backups are disabled. Removing the app deletes its internal library. Export stories before uninstalling.
- Only **text-based** PDFs are supported for text extraction. Scanned/image-only PDFs require OCR and are skipped with a message.
- Import limits: 25 MB per extracted document, 120 MB per imported archive, 200 archive entries. The model request includes an additional size guard. ZIP entries are never extracted via filesystem paths from the archive (no ZIP traversal).
- Sending **all** seeds can exceed the model's context window. The app reports the API error rather than silently omitting files.
- Chunks target roughly 1,250 words, and total word count is approximate. Each installment triggers an API request and may incur usage charges. The service can impose different context or output-token limits.
- Generation, ZIP import, PDF extraction and export run off the UI thread. The app saves each completed chunk; a cancelled/interrupted story stays in the library.
- The two-second word hold is a custom handler so default Android long-press text selection does not trigger an unrelated menu first. Move the finger to scroll; keep it still to select.
- Rewrites reuse the parent story's original seed IDs if they are still imported. If you delete seeds used by a story, you may need to import them again before rewriting.

## Testing status

Pure-Java `StoryAnchor` selection tests are in `tools/TestStoryAnchor.java`. Run with:

```bash
mkdir -p /tmp/seed-tests
javac -d /tmp/seed-tests app/src/main/java/com/seedscribe/app/StoryAnchor.java tools/TestStoryAnchor.java
java -cp /tmp/seed-tests TestStoryAnchor
```

**This archive is source code, not a compiled APK.** An Android SDK and access to Gradle/Maven dependencies were not available in the artifact creation environment, so the full app could not be built or installed here. Build it in Android Studio or through the included workflow and verify it on your device before relying on it.
