import com.seedscribe.app.StoryAnchor;
public class TestStoryAnchor {
    static void expect(boolean cond,String msg){if(!cond)throw new AssertionError(msg);}
    public static void main(String[] args){
        String text="The door creaked. The door shut.";
        int pos=text.lastIndexOf("door")+2;
        StoryAnchor a=StoryAnchor.at(text,pos);
        expect(a!=null && a.word.equals("door"),"word selection");
        expect(text.substring(0,a.endOffset).equals("The door creaked. The door"),"correct repeated-word cut");
        expect(StoryAnchor.at(text,0).word.equals("The"),"first word");
        expect(StoryAnchor.at(text,text.length()-1).word.equals("shut"),"tap just after word selects preceding word");
        expect(StoryAnchor.at("",0)==null,"empty text");
        expect(StoryAnchor.at("co-operate and don't",3).word.equals("co-operate"),"hyphenated word");
        System.out.println("StoryAnchor tests passed");
    }
}
